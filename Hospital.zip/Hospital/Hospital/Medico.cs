﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;


class Medico : Persona,IComparable<Medico>
{
    private string especialidad, disponibilidad; 
    private short codigo;
    public Medico(string nombre, string direccion, string tlf,short codigo, string especialidad,string disponibilidad)
        : base(nombre, direccion, tlf)
    {
        this.especialidad = especialidad;
        this.disponibilidad = disponibilidad;
        this.codigo = codigo;
    }
    public string GetEspecialidad { get { return especialidad; } set { especialidad = value; } }
    public short GetCodigo { get { return codigo; } set { codigo = value; } }
    public string GetDisponibilidad { get { return disponibilidad; } set { disponibilidad = value; } }

    public int CompareTo( Medico m)
    {
        return this.GetEspecialidad.CompareTo(m.GetEspecialidad);
    }

    public override string ToString()
    {
        return base.ToString()+", Especialidad:"+especialidad+", Disponibilidad:"+disponibilidad+", Código:" +
           GetCodigo;
    }
}

