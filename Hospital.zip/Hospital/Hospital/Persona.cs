﻿using System;
using System.Collections.Generic;
using System.Text;


class Persona
{
    private string nombre, direccion,tlf;

    public Persona(string nombre,string direccion,string tlf)
    {
        this.nombre = nombre;
        this.direccion = direccion;
        this.tlf = tlf;
    }
    public string GetNombre { get { return nombre; } set { nombre = value; } }
    public string GetDireccion { get { return direccion; } set { direccion = value; } }
    public string GetTlf { get { return tlf; } set { tlf= value; } }

    public override string ToString()
    {
        return nombre +", Dirección:"+ direccion+", "+"Teléfono:"+tlf;
    }
}

