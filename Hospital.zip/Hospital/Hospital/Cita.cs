﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;

class Cita:IComparable<Cita>
{
    private DateTime dia = new DateTime();
    private DateTime hora = new DateTime();
    private string sintomas, email;
    private short codigo;
    private string nombreCliente, nombreMedico;
    public Cita(string nombreCliente, DateTime dia,DateTime hora,string sintomas, string nombreMedico,string email,short codigo)
    {
        this.dia = dia;
        this.hora = hora;
        this.nombreCliente = nombreCliente;
        this.nombreMedico = nombreMedico;
        this.sintomas = sintomas;
        this.email = email;
        this.codigo = codigo;
    }

    public DateTime GetDia { get { return dia; }set { dia = value; } }
    public DateTime GetHora { get { return hora; } set { hora = value; } }
    public string GetMedico { get { return nombreMedico; } set { nombreMedico = value; } }
    public string GetCliente { get { return nombreCliente; }set { nombreCliente = value; } }
    public string GetSintomas { get { return sintomas; }set { sintomas = value; } }
    public string GetEmail { get { return email; } set { email = value; } }
    public short GetCodigo { get { return codigo; } set { codigo = value; } }

    public int CompareTo( Cita o)
    {
        return this.GetHora.CompareTo(o.GetHora);
    }
    public override string ToString()
    {
        string minute;
        if (GetHora.Minute < 10)
            minute = "0" + GetHora.Minute;
        else
            minute = Convert.ToString(GetHora.Minute);
        return "Cliente: "+GetCliente + " -- Día:" + GetDia.Date.Day+"/"+GetDia.Date.Month+"/"+GetDia.Date.Year + " -- Hora:"
            + GetHora.Hour + ":" + minute + " -- Médico: " + GetMedico + " -- Sintomas:" + GetSintomas + " -- Email: " 
            + GetEmail + " -- Código Cita:" + GetCodigo;
    }
    public void GenerarPdf()
    {
        Document doc = new Document(PageSize.LETTER);
        PdfWriter aviso = PdfWriter.GetInstance(doc, new FileStream("Aviso.pdf", FileMode.OpenOrCreate));
        
        doc.Open();
        // Creamos el tipo de Font que vamos utilizar
        iTextSharp.text.Font _standardFont = new iTextSharp.text.Font
            (iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);

        // Escribimos el encabezamiento en el documento
        doc.AddHeader("Recordatorio Cita","Hospital General Alicante");
        doc.AddCreationDate();
        doc.AddTitle("Recordatorio Cita");

        // Creamos la imagen y le ajustamos el tamaño
        iTextSharp.text.Image imagen = iTextSharp.text.Image.GetInstance("Hospital.jpg");
        imagen.BorderWidth = 0;
        imagen.Alignment = Element.ALIGN_RIGHT;
        float percentage = 0.0f;
        percentage = 150 / imagen.Width;
        imagen.ScalePercent(percentage * 100);
        //tuneamos minutos
        string minute;
        if (GetHora.Minute < 10)
            minute = "0" + GetHora.Minute;
        else
            minute =Convert.ToString( GetHora.Minute);
        // Insertamos la imagen en el documento y su contenido
        doc.Add(imagen);
        doc.Add(new Paragraph("Hospital General de Alicante",_standardFont));
        doc.Add(Chunk.NEWLINE);
        doc.Add(new Paragraph());
        doc.Add(new Paragraph("Cita Asistencia consulta",_standardFont));
        doc.Add(new Paragraph());
        doc.Add(new Paragraph("Cliente:"+GetCliente,_standardFont));
        doc.Add(new Paragraph());
        doc.Add(new Paragraph("Fecha de la cita:"+GetDia.Year + "/" + GetDia.Month + "/" + GetDia.Day));
        doc.Add(new Paragraph());
        doc.Add(new Paragraph("Hora de la cita:"+GetHora.Hour + ":" + minute));
        doc.Add(new Paragraph());
        doc.Add(new Paragraph("Médico asignado:"+GetMedico,_standardFont));
        doc.Add(new Paragraph());
        doc.Add(Chunk.NEWLINE);
        doc.Add(new Paragraph("Si necesita modificar o anular la cita llame al número de tlf: 965214521",_standardFont));
        doc.Close();
        aviso.Close();
    }
}
