﻿using System;
using System.Collections.Generic;
using System.Text;


class User
{
    private string nombre, clave;

    public User(string nombre, string clave)
    {
        this.nombre = nombre;
        this.clave = clave;
    }

    public string ONombre { get { return nombre; } set { nombre = value; } }
    public string OClave { get { return clave; } set { clave = value; } }

    public override string ToString()
    {
        return nombre +" Password:"+ clave;
    }
}


