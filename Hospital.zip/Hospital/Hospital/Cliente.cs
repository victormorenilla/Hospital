﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;


class Cliente:Persona,IComparable<Cliente>
{
    private string email;
    private byte edad;
    private short codigo;
    public Cliente(string nombre,string direccion,string tlf,short codigo,byte edad,string email) 
        : base(nombre, direccion, tlf)
    {
        this.codigo = codigo;
        this.email = email;
        this.edad = edad;
    }
    public Cliente(string nombre, string direccion, string tlf, short codigo, byte edad)
        : this(nombre, direccion, tlf, codigo,edad,"desconocido"){}
    public string GetEmail { get { return email; } set { email = value; } }
    public short GetCodigo { get { return codigo; } set { codigo = value; } }
    public byte GetEdad { get { return edad; } set { edad = value; } }

    public override string ToString()
    {
        return base.ToString()+ ", Email:"+email+", Edad:"+edad+", Codigo:"+codigo;
    }

    public int CompareTo(Cliente c)
    {
        return this.GetNombre.CompareTo(c.GetNombre);
    }
}

