﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using Document = iTextSharp.text.Document;
using System.Net.Mail;
using System.Configuration;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using System.Linq;
using System.Diagnostics.CodeAnalysis;
using System.Diagnostics;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Text;
using SpreadsheetLight;
using System.Collections;

class Organizacion
{
    static DateTime ahora = DateTime.Now;
    static bool test = false;
    static List<Cita> agenda = CargarAgenda();
    static List<Medico> cuadroMedico = CargarMedicos();
    static List<Cliente> clientes = CargarClientes();
    static string[] Menus = { "Menú Principal", "Menú Citas", "Menú Clientes", "Menú Médicos" };
    static void Main()
    {
        Console.BackgroundColor = ConsoleColor.Gray;

        ArrayList usuarios = LoadUser();       
        if (Registro(usuarios))
        {
            Console.Title="Hospital central";           
            MenuPrincipal(ahora, out test);
            if (test)
            {
                Console.Clear();
                Console.SetCursorPosition(30, 10);
                Console.WriteLine("Guardando datos y terminando procesos con seguridad.");
                Console.SetCursorPosition(0, Console.WindowHeight-6);
                Thread.Sleep(2000);
                return;
            }                            
        }       
    }
    
    //mostrar agenda//////////////////////////////////////////
    private static void MostrarAgenda(ref List<Cita> agenda,DateTime a)
    {
        bool hay = false;
        Console.Clear();
        Console.SetCursorPosition(0, 3);
        //agenda.Sort();
        foreach (Cita s in agenda)
        {
            if (s.GetDia.Date.Day == a.Date.Day && s.GetDia.Date.Month == a.Date.Month)
            {
                string minute;
                if (s.GetHora.Minute < 10)
                    minute = "0" + s.GetHora.Minute;
                else
                    minute = Convert.ToString(s.GetHora.Minute);
                Console.WriteLine("---------------------------");
                Console.WriteLine("Cliente:" + s.GetCliente);
                Console.WriteLine("Email contacto:" + s.GetEmail);
                Console.WriteLine("Fecha:" + s.GetDia.Day + "/" + s.GetDia.Month + "/" + s.GetDia.Year);
                Console.WriteLine("Hora de la cita:" + s.GetHora.Hour + ":" + minute);
                Console.WriteLine("Médico:" + s.GetMedico);
                Console.WriteLine("---------------------------");
                hay = true;
            }          
        }
        if (hay)
        {
            Console.WriteLine();
            Console.WriteLine("Pulse Intro para continuar.");
            Console.ReadLine();
            Console.Clear();
        }
        else
        {
            Console.WriteLine();
            Console.WriteLine("No hay citas en la agenda diaria.");
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Pulse Intro para continuar.");
            Console.ReadLine();
            Console.Clear();
        }
    }  
    // interfaz Médicos///////////////////////////////////////////
    private static void CrearMédicos(DateTime a, ref List<Medico>cuadroM)
    {       
        bool verif = false;
        string opcion;
        Console.Clear();
        do {
            CrearMarco();
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(Console.WindowWidth / 2, 1);
            Console.WriteLine(" -----------------------");
            Console.SetCursorPosition(Console.WindowWidth / 2, 2);
            Console.WriteLine("| Bienvenido: {0}/{1}/{2} |", a.Day, a.Month, a.Year);
            Console.SetCursorPosition(Console.WindowWidth / 2, 3);
            Console.WriteLine(" -----------------------");
            Console.SetCursorPosition(Console.WindowWidth -20,Console.WindowHeight-4);
            Console.WriteLine(" --------------");
            Console.SetCursorPosition(Console.WindowWidth -20, Console.WindowHeight - 3);
            Console.WriteLine("| "+Menus[3]+" |");
            Console.SetCursorPosition(Console.WindowWidth -20, Console.WindowHeight - 2);
            Console.WriteLine(" --------------");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine(" ------------------");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("| 1.Añadir Médico. |");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine(" ------------------");
            Console.SetCursorPosition(2, 6);
            Console.WriteLine(" ---------------------");
            Console.SetCursorPosition(2, 7);
            Console.WriteLine("| 2.Modificar Médico. |");
            Console.SetCursorPosition(2, 8);
            Console.WriteLine(" ---------------------");
            Console.SetCursorPosition(2, 9);
            Console.WriteLine(" --------------------");
            Console.SetCursorPosition(2, 10);
            Console.WriteLine("| 3.Eliminar Médico. |");
            Console.SetCursorPosition(2, 11);
            Console.WriteLine(" --------------------");
            Console.SetCursorPosition(2, 12);
            Console.WriteLine(" --------------------");
            Console.SetCursorPosition(2, 13);
            Console.WriteLine("| 4.Mostrar Médicos. |");
            Console.SetCursorPosition(2, 14);
            Console.WriteLine(" --------------------");
            Console.SetCursorPosition(2, 15);
            Console.WriteLine(" ------------------");
            Console.SetCursorPosition(2, 16);
            Console.WriteLine("| 5.Buscar Médico. |");
            Console.SetCursorPosition(2, 17);
            Console.WriteLine(" ------------------");
            Console.SetCursorPosition(2, 18);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(2, 19);
            Console.WriteLine("| M.Menú Principal. |");
            Console.SetCursorPosition(2, 20);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(3, 21);
            opcion = Console.ReadLine();
            switch (opcion)
            {
                case "1":AnyadirMedico(ref cuadroM);break;
                case "2":ModificarMedico(ref cuadroM); break;
                case "3":EliminarMedico(ref cuadroM); break;
                case "4":MostrarMedicos(ref cuadroM); break;
                case "5":BuscarMedicos(ref cuadroM); break;
                case "M":
                case "m":MenuPrincipal(a,out test); verif = true;break;
                default:
                    Console.SetCursorPosition(3, 22);
                    Console.WriteLine("Opción no disponible.");
                    Thread.Sleep(1000);
                    Console.Clear(); break;
            }
            Console.WriteLine();
        } while (!verif);      
    }
        //buscar médicos
    private static void BuscarMedicos(ref List<Medico> cuadroM)
    {
        Console.Clear();
        bool encontrado = false;
        Console.SetCursorPosition(0, 3);
        string datos = PedirDatos("Introduzca Nombre del Médico/Especialidad a buscar");

        for(int i=0;i<cuadroM.Count;i++)
        {
            if (cuadroM[i].GetNombre.ToLower().Contains(datos.ToLower()))
            {               
                Console.WriteLine("---------------------------");
                Console.WriteLine("Código:" + cuadroM[i].GetCodigo + " / " + cuadroM[i].GetNombre);
                Console.WriteLine("Especialidad:" + cuadroM[i].GetEspecialidad);
                Console.WriteLine("Disponible:" + cuadroM[i].GetDisponibilidad);
                Console.WriteLine("Teléfono:" + cuadroM[i].GetTlf);
                Console.WriteLine("---------------------------");
                encontrado = true;
            }
            else if (cuadroM[i].GetEspecialidad.ToLower().Contains(datos.ToLower()))
            {               
                Console.WriteLine("---------------------------");
                Console.WriteLine("Código:" + cuadroM[i].GetCodigo + " / " + cuadroM[i].GetNombre);
                Console.WriteLine("Especialidad:" + cuadroM[i].GetEspecialidad);
                Console.WriteLine("Disponible:" + cuadroM[i].GetDisponibilidad);
                Console.WriteLine("Teléfono:" + cuadroM[i].GetTlf);
                Console.WriteLine("---------------------------");
                encontrado = true;
            }
        }
        if (encontrado)
        {
            Console.WriteLine();
            Console.WriteLine("Pulse Intro para continuar.");
            Console.ReadLine();
            Console.Clear();
        }
        if (!encontrado)
        {
            Console.WriteLine();
            Console.WriteLine("Sin coincidencias en la busqueda.");
            Thread.Sleep(1000);
            Console.Clear();
        }
    }
    //mostrar médicos
    private static void MostrarMedicos(ref List<Medico>cuadroMedico)
    {
        Console.Clear();
        Console.SetCursorPosition(0, 3);
        cuadroMedico.Sort();
        foreach (Medico m in cuadroMedico)
        {
            Console.WriteLine("---------------------------");
            Console.WriteLine("Código:"+m.GetCodigo+" / "+m.GetNombre);
            Console.WriteLine("Especialidad:" + m.GetEspecialidad);
            Console.WriteLine("Disponible:" + m.GetDisponibilidad);
            Console.WriteLine("Teléfono:" + m.GetTlf);
            Console.WriteLine("---------------------------");
        }
        Console.WriteLine();
        Console.WriteLine("Pulse Intro para continuar.");
        Console.ReadLine();
        Console.Clear();
    }
    //eliminar médico
    private static void EliminarMedico(ref List<Medico> cuadroMedico)
    {
        bool encontrado = false;
        short cod;
        string decision;
        Medico nMedico = null;
        try
        {
            Console.Clear();
            Console.SetCursorPosition(0, 3);
            cod = Convert.ToInt16(PedirDatos("Introduzca el código del médico"));
        
            foreach (Medico m in cuadroMedico)
            {
                if (m.GetCodigo.Equals(cod))
                {
                    Console.WriteLine("---------------------------");
                    Console.WriteLine("Código:" + m.GetCodigo + " / " + m.GetNombre);
                    Console.WriteLine("Especialidad:" + m.GetEspecialidad);
                    Console.WriteLine("Disponible:" + m.GetDisponibilidad);
                    Console.WriteLine("Teléfono:" + m.GetTlf);
                    Console.WriteLine("---------------------------");
                    encontrado = true;
                    nMedico = m;
                }
            }
            if (encontrado)
            {
                decision = PedirDatos("Desea borrarlo definitivamente S/N");
                switch (decision.ToLower())
                {
                    case "si":
                    case "s":
                        if (cuadroMedico.Contains(nMedico)){ cuadroMedico.Remove(nMedico); } 
                        Console.WriteLine("Médico Eliminado");
                        Thread.Sleep(1000); Console.Clear(); break;
                    case "n":
                    case "no":
                        Console.WriteLine("Eliminación cancelada.");
                        Thread.Sleep(1000); Console.Clear(); break;
                    default:
                        Console.WriteLine("Opción no disponible.");
                        Thread.Sleep(1000); Console.Clear(); break;
                }
            }
            if (!encontrado)
            {
                Console.WriteLine("El código de Médico no existe.");
                Thread.Sleep(1000);
                Console.Clear();
            }
        }
        catch (Exception e)
        {
            Console.WriteLine("Formato no correcto, el código es númerico." + e.Message);
            Thread.Sleep(1000);
            Console.Clear();
        }
    }
    //modificar médico
    private static void ModificarMedico(ref List<Medico> cuadroMedico)
    {
        bool verif = false;
        try
        {
            Console.Clear();
            Console.SetCursorPosition(0, 3);
            short cod = Convert.ToInt16(PedirDatos("Código del Médico a modificar"));
            foreach (Medico c in cuadroMedico)
            {
                if (cod.Equals(c.GetCodigo))
                {
                    Console.Clear();
                    Console.SetCursorPosition(0, 3);
                    Console.WriteLine("---------------------------");
                    Console.WriteLine("Código:" + c.GetCodigo + " / " + c.GetNombre);
                    Console.WriteLine("Especialidad:" + c.GetEspecialidad);
                    Console.WriteLine("Disponible:" + c.GetDisponibilidad);
                    Console.WriteLine("Teléfono:" + c.GetTlf);
                    Console.WriteLine("---------------------------");
                    Console.WriteLine();
                    string nombre, direccion, tlf, especialidad, disponibilidad;
                    nombre = PedirDatos("Nombre");
                    if (nombre != "")
                        c.GetNombre = nombre;
                    direccion = PedirDatos("Dirección");
                    if (direccion != "")
                        c.GetDireccion = direccion;
                    tlf = PedirDatos("Teléfono");
                    if (tlf != "")
                        c.GetTlf = tlf;
                    especialidad = PedirDatos("Especialidad");
                    if (especialidad != "")
                        c.GetEspecialidad = especialidad;
                    disponibilidad = PedirDatos("Disponibilidad");
                    if (disponibilidad != "")
                        c.GetEspecialidad = disponibilidad;
                    Console.Clear();
                    verif = true;
                }
            }
            if (!verif)
            {
                Console.WriteLine("No se encuentra Médico con ese código.");
                Thread.Sleep(1000);
                Console.Clear();
            }
        }        
        catch (Exception)
        {
            Console.WriteLine("Formato no correcto el código es númerico.");
            Thread.Sleep(1000);
            Console.Clear();
        }
    }
    //añadir médico
    private static void AnyadirMedico(ref List<Medico> cuadroMedico) 
    {
        int maxCodigo=0;
        foreach(Medico m in cuadroMedico)
        {
            if (maxCodigo < m.GetCodigo)
                maxCodigo = m.GetCodigo;
        }
        Console.Clear();
        Console.SetCursorPosition(0, 3);
        string nombre, direccion, tlf, especialidad, disponibilidad;
        short codigo;
        do
        {
            nombre = PedirDatos("Nombre");
            if (nombre == "") { Console.WriteLine("El campo no puede estar vacio."); }
        } while (nombre == "");
        direccion = PedirDatos("Dirección");
        do
        {
            tlf = PedirDatos("Teléfono");
        } while (tlf=="");
        codigo =(short)(maxCodigo +1);
        do
        {
            especialidad = PedirDatos("Especialidad");
            if (especialidad == "") { Console.WriteLine("El campo no puede estar vacío."); }
        } while (especialidad=="");
        do
        {
            disponibilidad = PedirDatos("Disponibilidad");
            if (especialidad == "") { Console.WriteLine("El campo no puede estar vacío."); }
        } while (disponibilidad == "");
        cuadroMedico.Add(new Medico(nombre, direccion, tlf, codigo, especialidad, disponibilidad));
        Console.Clear();
    }
     //interfaz Cliente
    private static void CrearClientes(DateTime a,ref List<Cliente> clientes)
    {
        bool verif = false;
        string opcion;
        Console.Clear();
        do
        {
            CrearMarco();
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(Console.WindowWidth / 2, 1);
            Console.SetCursorPosition(Console.WindowWidth / 2, 1);
            Console.WriteLine(" -----------------------");
            Console.SetCursorPosition(Console.WindowWidth / 2, 2);
            Console.WriteLine("| Bienvenido: {0}/{1}/{2} |", a.Day, a.Month, a.Year);
            Console.SetCursorPosition(Console.WindowWidth / 2, 3);
            Console.WriteLine(" -----------------------");
            Console.SetCursorPosition(Console.WindowWidth - 20, Console.WindowHeight - 4);
            Console.WriteLine(" ---------------");
            Console.SetCursorPosition(Console.WindowWidth - 20, Console.WindowHeight - 3);
            Console.WriteLine("| " + Menus[2] + " |");
            Console.SetCursorPosition(Console.WindowWidth - 20, Console.WindowHeight - 2);
            Console.WriteLine(" ---------------");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("| 1.Añadir Cliente. |");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(2, 6);
            Console.WriteLine(" ----------------------");
            Console.SetCursorPosition(2, 7);
            Console.WriteLine("| 2.Modificar Cliente. |");
            Console.SetCursorPosition(2, 8);
            Console.WriteLine(" ----------------------");
            Console.SetCursorPosition(2, 9);
            Console.WriteLine(" ---------------------");
            Console.SetCursorPosition(2, 10);
            Console.WriteLine("| 3.Eliminar Cliente. |");
            Console.SetCursorPosition(2, 11);
            Console.WriteLine(" ---------------------");
            Console.SetCursorPosition(2, 12);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(2, 13);
            Console.WriteLine("| 4.Buscar Cliente. |");
            Console.SetCursorPosition(2, 14);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(2, 15);
            Console.WriteLine(" ---------------------");
            Console.SetCursorPosition(2, 16);
            Console.WriteLine("| 5.Mostrar Clientes. |");
            Console.SetCursorPosition(2, 17);
            Console.WriteLine(" ---------------------");
            Console.SetCursorPosition(2, 18);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(2, 19);
            Console.WriteLine("| M.Menú Principal. |");
            Console.SetCursorPosition(2, 20);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(3, 21);
            opcion = Console.ReadLine();
            switch (opcion)
            {
                case "1": AnyadirCliente(ref clientes); break;
                case "2": ModificarCliente(ref clientes); break;
                case "3": EliminarCliente(ref clientes); break;
                case "4": BuscarCliente(ref clientes);  break;
                case "5": MostrarCliente(ref clientes); break;
                case "M":
                case "m": MenuPrincipal(a, out test); verif = true; break;
                default:
                    Console.SetCursorPosition(3, 22);
                    Console.WriteLine("Opción no disponible.");
                    Thread.Sleep(1000);Console.Clear(); break;
            }
            Console.WriteLine();
        } while (!verif);
    }
    //buscar cliente
    private static void BuscarCliente(ref List<Cliente> clientes)
    {
        bool test = false;
        Console.Clear();
        Console.SetCursorPosition(0, 3);
        clientes.Sort();
        string nombre = PedirDatos("Nombre del cliente a buscar");
        foreach (Cliente s in clientes)
        {
            if (s.GetNombre.ToLower().Contains(nombre.ToLower()))
            {
                Console.WriteLine("---------------------------");
                Console.WriteLine("Código:" + s.GetCodigo);
                Console.WriteLine("Cliente:" + s.GetNombre);
                Console.WriteLine("Email contacto:" + s.GetEmail);
                Console.WriteLine("Dirección:" + s.GetDireccion);
                Console.WriteLine("Teléfono:" + s.GetTlf);
                Console.WriteLine("Edad:" + s.GetEdad);
                Console.WriteLine("---------------------------");
                test = true;
            }            
        }
        Console.WriteLine();
        if (!test) { Console.WriteLine("Cliente no encontrado."); }
        Console.WriteLine();
        Console.WriteLine("Pulse Intro para continuar.");
        Console.ReadLine();
        Console.Clear();
    }
    //mostrar cliente
    private static void MostrarCliente(ref List<Cliente> clientes)
    {    
        Console.Clear();
        Console.SetCursorPosition(0, 3);
        clientes.Sort();
        foreach (Cliente s in clientes)       
        {
            Console.WriteLine("---------------------------");
            Console.WriteLine("Código:" + s.GetCodigo);
            Console.WriteLine("Cliente:" + s.GetNombre);
            Console.WriteLine("Email contacto:" + s.GetEmail);
            Console.WriteLine("Dirección:" + s.GetDireccion);
            Console.WriteLine("Teléfono:" + s.GetTlf);
            Console.WriteLine("Edad:" + s.GetEdad);
            Console.WriteLine("---------------------------");
        }
        Console.WriteLine();
        Console.WriteLine("Pulse Intro para continuar.");
        Console.ReadLine();
        Console.Clear();       
    }
    //eliminar cliente
    private static void EliminarCliente(ref List<Cliente> clientes)
    {
        bool encontrado = false;
        short cod;
        string decision;
        Cliente nCliente=null;
        try
        {
            Console.Clear();
            Console.SetCursorPosition(0, 3);
            cod = Convert.ToInt16(PedirDatos("Introduzca el código del cliente"));
            foreach (Cliente m in clientes)
            {
                if (m.GetCodigo.Equals(cod))
                {
                    Console.WriteLine("---------------------------");
                    Console.WriteLine("Código:" + m.GetCodigo + " / " + m.GetNombre);
                    Console.WriteLine("Dirección:" + m.GetDireccion);
                    Console.WriteLine("Email:" + m.GetEmail);
                    Console.WriteLine("Teléfono:" + m.GetTlf);
                    Console.WriteLine("Edad:" + m.GetEdad);
                    Console.WriteLine("---------------------------");
                    encontrado = true;
                    nCliente = m;                   
                }
            }
            if (encontrado)
            {
                decision = PedirDatos("Desea borrarlo definitivamente S/N");
                switch (decision.ToLower())
                {
                    case "s":
                        if (clientes.Contains(nCliente)) { clientes.Remove(nCliente); }
                        Console.WriteLine("Cliente Eliminado");
                        Thread.Sleep(1000); Console.Clear(); break;
                    case "n":
                        Console.WriteLine("Eliminación cancelada.");
                        Thread.Sleep(1000); Console.Clear(); break;
                    default:
                        Console.WriteLine("Opción no disponible.");
                        Thread.Sleep(1000); Console.Clear(); break;
                }
            }
            if (!encontrado)
            {
                Console.WriteLine("El código de cliente no existe.");
                Thread.Sleep(1000);
                Console.Clear();
            }
        }
        catch (Exception)
        {
            Console.WriteLine("Formato no correcto el código es númerico.");
            Thread.Sleep(1000);
            Console.Clear();
        }
    }
    //modificar cliente
    private static void ModificarCliente(ref List<Cliente> clientes)
    {
        bool verif = false;
        try
        {
            Console.Clear();
            Console.SetCursorPosition(0, 3);
            short cod = Convert.ToInt16(PedirDatos("Código del cliente a modificar"));
            foreach (Cliente c in clientes)
            {
                if (cod.Equals(c.GetCodigo))
                {

                    Console.WriteLine("---------------------------");
                    Console.WriteLine("Código:" + c.GetCodigo + " / " + c.GetNombre);
                    Console.WriteLine("Dirección:" + c.GetDireccion);
                    Console.WriteLine("Email:" + c.GetEmail);
                    Console.WriteLine("Teléfono:" + c.GetTlf);
                    Console.WriteLine("Edad:" + c.GetEdad);
                    Console.WriteLine("---------------------------");
                    string nombre, direccion, tlf, email;
                    byte edad;
                    nombre = PedirDatos("Nombre");
                    if (nombre != "")
                        c.GetNombre = nombre;
                    direccion = PedirDatos("Dirección");
                    if (direccion != "")
                        c.GetDireccion = direccion;
                    tlf = PedirDatos("Teléfono");
                    if (tlf != "")
                        c.GetTlf = tlf;
                    edad = Convert.ToByte(PedirDatos("Edad"));
                    if (Convert.ToString(edad) != "")
                        c.GetEdad = edad;
                    email = PedirDatos("Email");
                    if (email != "")
                        c.GetEmail = email;
                    Console.Clear();
                    verif = true;
                }
            }
            if (!verif)
            {
                Console.WriteLine("No se encuentra el cliente.");
                Thread.Sleep(1000);
                Console.Clear();
            }
        }       
        catch (Exception)
        {
            Console.WriteLine("Formato no correcto la edad es campo númerico.");
            Thread.Sleep(1000);
            Console.Clear();
        }
    }
    //añadir cliente
    private static void AnyadirCliente(ref List<Cliente> clientes)
    {
        int maxCodigo = 0;
        foreach (Cliente c in clientes)
        {
            if (maxCodigo < c.GetCodigo)
                maxCodigo = c.GetCodigo;
        }
        Console.Clear();
        Cliente newCliente;
        Console.SetCursorPosition(0, 3);
        string nombre, direccion, tlf, email;
        short codigo;
        byte edad;
        do
        {
            nombre = PedirDatos("Nombre");
            if (nombre == "") { Console.WriteLine("El campo no puede estar vacio."); }
        } while (nombre== "");
        do
        {
            direccion = PedirDatos("Dirección");
            if (direccion == "") { Console.WriteLine("El campo no puede estar vacío."); }
        } while (direccion == "");       
        tlf = PedirDatos("Teléfono");
        if (tlf == "") { Console.WriteLine("Aviso va dejar el campo vacío."); }
        codigo = (short)(maxCodigo + 1);
        try 
        {
            edad = Convert.ToByte(PedirDatos("Edad"));
            email = PedirDatos("Email");
            if (email == "") { newCliente = new Cliente(nombre, direccion, tlf, codigo, edad); }
            else { newCliente = new Cliente(nombre, direccion, tlf, codigo, edad, email); };
            clientes.Add(newCliente);
            Console.Clear();
        }
        catch (Exception)
        {
            Console.WriteLine("Formato no correcto la edad es un campo númerico.");
            Thread.Sleep(1000);
            Console.Clear();
        }       
    }
    //interfaz citas
    private static void CrearCitas(DateTime a,ref List<Cliente>clientes,ref List<Medico>cuadroMedico,ref List<Cita>agenda)
    {
        bool verif = false;
        string opcion;
        Console.Clear();
        do
        {
            CrearMarco();
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(Console.WindowWidth / 2, 1);
            Console.WriteLine(" -----------------------");
            Console.SetCursorPosition(Console.WindowWidth / 2, 2);
            Console.WriteLine("| Bienvenido: {0}/{1}/{2} |", a.Day, a.Month, a.Year);
            Console.SetCursorPosition(Console.WindowWidth / 2, 3);
            Console.WriteLine(" -----------------------");
            Console.SetCursorPosition(Console.WindowWidth - 20, Console.WindowHeight - 4);
            Console.WriteLine(" ------------");
            Console.SetCursorPosition(Console.WindowWidth - 20, Console.WindowHeight - 3);
            Console.WriteLine("| " + Menus[1] + " |");
            Console.SetCursorPosition(Console.WindowWidth - 20, Console.WindowHeight - 2);
            Console.WriteLine(" ------------");
            Console.SetCursorPosition(2, 3);
            Console.WriteLine(" -----------------------------");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine("| 1.Agenda de citas para hoy. |");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine(" -----------------------------");
            Console.SetCursorPosition(2, 6);
            Console.WriteLine(" -----------------");
            Console.SetCursorPosition(2, 7);
            Console.WriteLine("| 2.Añadir Citas. |");
            Console.SetCursorPosition(2, 8);
            Console.WriteLine(" -----------------");
            Console.SetCursorPosition(2, 9);
            Console.WriteLine(" --------------------");
            Console.SetCursorPosition(2, 10);
            Console.WriteLine("| 3.Modificar Citas. |");
            Console.SetCursorPosition(2,11);
            Console.WriteLine(" --------------------");
            Console.SetCursorPosition(2, 12);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(2, 13);
            Console.WriteLine("| 4.Eliminar Citas. |");
            Console.SetCursorPosition(2, 14);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(2, 15);
            Console.WriteLine(" ----------------------------");
            Console.SetCursorPosition(2, 16);
            Console.WriteLine("| 5.Mostrar todas las citas. |");
            Console.SetCursorPosition(2, 17);
            Console.WriteLine(" ----------------------------");
            Console.SetCursorPosition(2, 18);
            Console.WriteLine(" -----------------");
            Console.SetCursorPosition(2, 19);
            Console.WriteLine("| 6.Buscar Citas. |");
            Console.SetCursorPosition(2, 20);
            Console.WriteLine(" -----------------");
            Console.SetCursorPosition(2, 21);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(2, 22);
            Console.WriteLine("| M.Menú Principal. |");
            Console.SetCursorPosition(2, 23);
            Console.WriteLine(" -------------------");
            Console.SetCursorPosition(3, 24);
            opcion = Console.ReadLine();
            switch (opcion)
            {
                case "1":MostrarAgenda(ref agenda, a);break;
                case "2": AnyadirCitas(a, ref clientes, ref cuadroMedico, ref agenda); break;
                case "3": ModificarCitas(ref agenda); break;
                case "4": EliminarCitas(ref agenda); break;
                case "5": MostrarCitas(ref agenda); break;
                case "6": BuscarCitas(ref agenda); break;
                case "M":
                case "m": MenuPrincipal(a, out test); verif = true; break;
                default:
                    Console.SetCursorPosition(3, 25);
                    Console.WriteLine("Opción no disponible.");
                    Thread.Sleep(1000); Console.Clear(); break;
            }
            Console.WriteLine();
        } while (!verif);
    }
    //buscar citas
    private static void BuscarCitas(ref List<Cita> agenda)
    {
        bool encontrado = false;
        Console.Clear();
        try
        {
            Console.SetCursorPosition(0, 3);
            short cod = Convert.ToInt16(PedirDatos("Código de cita a mostrar"));
            foreach (Cita m in agenda)
            {
                if (m.GetCodigo.Equals(cod))
                {
                    string minute;
                    if (m.GetHora.Minute < 10)
                        minute = "0" + m.GetHora.Minute;
                    else
                        minute = Convert.ToString(m.GetHora.Minute);
                    Console.SetCursorPosition(0, 3);
                    Console.WriteLine("---------------------------");
                    Console.WriteLine("Código:" + m.GetCodigo);
                    Console.WriteLine("Cliente:" + m.GetCliente);
                    Console.WriteLine("Email contacto:" + m.GetEmail);
                    Console.WriteLine("Fecha:" +m.GetDia.Day + "/" + m.GetDia.Month + "/" + m.GetDia.Year);
                    Console.WriteLine("Hora de la cita:" + m.GetHora.Hour + ":" + minute);
                    Console.WriteLine("Médico:" + m.GetMedico);
                    Console.WriteLine("---------------------------");
                    encontrado = true;
                    Console.WriteLine();
                    Console.WriteLine("Pulse Intro para continuar.");
                    Console.ReadLine();
                    Thread.Sleep(1000);
                    Console.Clear();
                }
            }
            if (!encontrado)
            {
                Console.WriteLine("No se encuentra la cita.");
                Thread.Sleep(1000);
                Console.Clear();
            }
        }
        catch (Exception)
        {
            Console.WriteLine("Formato no correcto el código es númerico.");
            Thread.Sleep(1000);
            Console.Clear();
        }
    }
    //mostrar citas
    private static void MostrarCitas(ref List<Cita> agenda)
    {
        string minute;
        Console.Clear();
        Console.SetCursorPosition(0, 3);
        List<Cita> agendaMod = agenda.OrderBy(x => x.GetDia.Date).ToList();
        foreach (Cita s in agendaMod)
        {
            if (s.GetDia.Date < ahora.Date)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                if (s.GetHora.Minute < 10)
                    minute = "0" + s.GetHora.Minute;
                else
                    minute = Convert.ToString(s.GetHora.Minute);
                Console.WriteLine("---------------------------");
                Console.WriteLine("Código:" + s.GetCodigo);
                Console.WriteLine("Cliente:" + s.GetCliente);
                Console.WriteLine("Email contacto:" + s.GetEmail);
                Console.WriteLine("Fecha:" + s.GetDia.Day + "/" + s.GetDia.Month + "/" + s.GetDia.Year);
                Console.WriteLine("Hora de la cita:" + s.GetHora.Hour + ":" + minute);
                Console.WriteLine("Médico:" + s.GetMedico);
                Console.WriteLine("---------------------------");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Black;
                if (s.GetHora.Minute < 10)
                    minute = "0" + s.GetHora.Minute;
                else
                    minute = Convert.ToString(s.GetHora.Minute);
                Console.WriteLine("---------------------------");
                Console.WriteLine("Código:" + s.GetCodigo);
                Console.WriteLine("Cliente:" + s.GetCliente);
                Console.WriteLine("Email contacto:" + s.GetEmail);
                Console.WriteLine("Fecha:" + s.GetDia.Day + "/" + s.GetDia.Month + "/" + s.GetDia.Year);
                Console.WriteLine("Hora de la cita:" + s.GetHora.Hour + ":" + minute);
                Console.WriteLine("Médico:" + s.GetMedico);
                Console.WriteLine("---------------------------");
            }                     
        }
        Console.ForegroundColor = ConsoleColor.Black;
        Console.WriteLine();
        Console.WriteLine("Pulse Intro para continuar.");
        Console.ReadLine();       
        Console.Clear();
    }
    //eliminar citas
    private static void EliminarCitas(ref List<Cita> agenda)
    {
        bool test = false;
        short cod;
        string verif;
        Cita nCita = null;
        Console.Clear();
        try
        {
            Console.SetCursorPosition(0, 3);
            cod =Convert.ToInt16( PedirDatos("Código de la cita a eliminar"));
            foreach(Cita c in agenda)
            {
                if (cod.Equals(c.GetCodigo))
                {
                    
                    string minute;
                    test = true;
                    if (c.GetHora.Minute < 10)
                        minute = "0" + c.GetHora.Minute;
                    else
                        minute = Convert.ToString(c.GetHora.Minute);
                    Console.WriteLine("---------------------------");
                    Console.WriteLine("Código:" + c.GetCodigo);
                    Console.WriteLine("Cliente:" + c.GetCliente);
                    Console.WriteLine("Email contacto:" + c.GetEmail);
                    Console.WriteLine("Fecha:" + c.GetDia.Day + "/" + c.GetDia.Month + "/" + c.GetDia.Year);
                    Console.WriteLine("Hora de la cita:" + c.GetHora.Hour + ":" + minute);
                    Console.WriteLine("Médico:" + c.GetMedico);
                    Console.WriteLine("---------------------------");
                    nCita = c;
                }
            }
            if (test)
            {
                verif = PedirDatos("Desea eliminar la cita S/N");
                switch (verif.ToLower())
                {
                    case "s":
                        if (agenda.Contains(nCita)) { agenda.Remove(nCita); }
                        Console.WriteLine("Cita eliminada.");
                        Thread.Sleep(1500); Console.Clear();
                        break;
                    case "n":
                        Console.WriteLine("Cancelado no se eliminará la cita.");
                        Thread.Sleep(1500); Console.Clear();
                        break;
                    default:
                        Console.WriteLine("Opción no disponible.");
                        Thread.Sleep(1500); Console.Clear(); break;
                }
            }
            if (!test)
            {
                Console.WriteLine("Código de cita no encontrado..");
                Thread.Sleep(1500); 
                Console.Clear();
            }
        }
        catch (Exception)
        {
            Console.WriteLine("Formato incorrecto el código es númerico.");
            Thread.Sleep(1500);
            Console.Clear();
        }
    }
    //modificar citas
    private static void ModificarCitas(ref List<Cita> agenda)
    {
        bool verif = false;
        Console.Clear();
        try
        {
            Console.SetCursorPosition(0, 3);
            short cod = Convert.ToInt16(PedirDatos("Código de la cita a modificar"));
            foreach (Cita c in agenda)
            {
                if (cod.Equals(c.GetCodigo))
                {
                    string minute;
                    test = true;
                    if (c.GetHora.Minute < 10)
                        minute = "0" + c.GetHora.Minute;
                    else
                        minute = Convert.ToString(c.GetHora.Minute);
                    Console.WriteLine("---------------------------");
                    Console.WriteLine("Código:" + c.GetCodigo);
                    Console.WriteLine("Cliente:" + c.GetCliente);
                    Console.WriteLine("Email contacto:" + c.GetEmail);
                    Console.WriteLine("Fecha:" + c.GetDia.Day + "/" + c.GetDia.Month + "/" + c.GetDia.Year);
                    Console.WriteLine("Hora de la cita:" + c.GetHora.Hour + ":" + minute);
                    Console.WriteLine("Médico:" + c.GetMedico);
                    Console.WriteLine("---------------------------");
                    string nomCliente,nomMedico, email;
                    DateTime dia, hora;
                    
                    nomCliente = PedirDatos("Nombre de cliente");
                    if (nomCliente != "")
                        c.GetCliente = nomCliente;
                    email = PedirDatos("Email");
                    if (email != "")
                        c.GetEmail = email; 
                    try
                    {
                        dia = Convert.ToDateTime(PedirDatos("Nueva fecha"));
                        c.GetDia = dia;
                        hora = Convert.ToDateTime(PedirDatos("Nueva hora"));
                        c.GetHora = hora;
                        nomMedico = PedirDatos("Médico");
                        if (nomMedico != "")
                            c.GetMedico = nomMedico;
                        Console.WriteLine("Cita modificada.");
                        Console.Clear();
                        verif = true;
                        if (!verif)
                        {
                            Console.WriteLine("No se encuentra la cita.");
                            Thread.Sleep(1000);
                            Console.Clear();
                        }
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Formato incorrecto día/hora o vacío.");
                        Thread.Sleep(1500);
                        Console.Clear();
                    }                                                       
                }
            }          
        }
        catch (Exception)
        {
            Console.WriteLine("Formato incorrecto el código es númerico.");
            Thread.Sleep(1500);
            Console.Clear();
        }
    }
    //añadir citas
    private static void AnyadirCitas(DateTime a,ref List<Cliente> clientes, ref List<Medico> cuadroMedico, ref List<Cita> agenda)
    {
        int maxCodigo = 0;
        foreach (Cita x in agenda)
        {
            if (maxCodigo < x.GetCodigo)
                maxCodigo = x.GetCodigo;
        }
        Console.Clear();
        Process proc;
        short codigo;
        string deci;
        bool test = false;
        string nombreCliente, especialidad, nombreMedico, email;
        DateTime dia = a.Date, hora = a.Date;
        Console.SetCursorPosition(0, 3);
        do
        {
            nombreCliente = PedirDatos("Nombre del paciente");
            if(nombreCliente == "") { Console.WriteLine("El campo no puede estar vacío."); }
        } while (nombreCliente == "");
            
        foreach (Cliente nc in clientes)
        {
            if (nc.GetNombre.ToLower().Equals(nombreCliente.ToLower()))
            {
                Console.WriteLine("El cliente ya existe");
                test = true;
            }
        }
        if (!test)
        {
            deci = PedirDatos("El cliente no existe, desea guardar el cliente S/N");
            switch (deci.ToLower())
            {
                case "s":
                case "si":
                    AnyadirCliente(ref clientes);
                    Console.SetCursorPosition(0, 3); break;
                case "n":
                case "no": break;
            }
        }
        try
        {
            dia = Convert.ToDateTime(PedirDatos("Día de la consulta (Formato d/m/yyyy)"));
            hora = Convert.ToDateTime(PedirDatos("Hora de la consulta"));

        }
        catch (Exception)
        {
            Console.WriteLine("Formato no válido.");
            Thread.Sleep(2000);
            Console.Clear();
            CrearCitas(a, ref clientes, ref cuadroMedico, ref agenda);
        }
        especialidad = PedirDatos("Especialidad");
        PdfMedicoEsp(cuadroMedico, especialidad);
        string resp = PedirDatos("Ver listado médicos disponibles por especialidad S/N");
        if (resp.ToLower().Equals("si") || resp.ToLower().Equals("s"))
        {
            proc = Process.Start(@"D:\NITRO\NitroPDF.exe", "ListadoEspecialidad.pdf");
        }
        nombreMedico = PedirDatos("Nombre del Médico");
        email = PedirDatos("Email de contacto");
        codigo = (short)(maxCodigo + 1);
        Cita c = new Cita(nombreCliente, dia, hora, especialidad, nombreMedico, email, codigo);
        c.GenerarPdf();
        agenda.Add(c);
        EnviarCorreo(c.GetEmail);
        Console.Clear();
        
    }
    //crear pdf medico por especialidad
    private static void PdfMedicoEsp(List<Medico> cuadroMedico,string especialidad)
    {
        cuadroMedico.Sort();
        Document doc = new Document(PageSize.LETTER);
        PdfWriter aviso = PdfWriter.GetInstance(doc, new FileStream("ListadoEspecialidad.pdf", FileMode.OpenOrCreate));

        doc.Open();        
        // Creamos el tipo de Font que vamos utilizar
        iTextSharp.text.Font _standardFont = new iTextSharp.text.Font
            (iTextSharp.text.Font.FontFamily.HELVETICA, 12, iTextSharp.text.Font.NORMAL, BaseColor.BLACK);

        // Escribimos el encabezamiento en el documento
        doc.AddHeader("Lista Médicos Disponibles por especialidad", "Hospital General Alicante");
        doc.AddCreationDate();
        doc.AddTitle("Lista Especialidad");

        // Creamos la imagen y le ajustamos el tamaño
        iTextSharp.text.Image imagen = iTextSharp.text.Image.GetInstance("Hospital.jpg");
        imagen.BorderWidth = 0;
        imagen.Alignment = Element.ALIGN_RIGHT;
        float percentage = 0.0f;
        percentage = 150 / imagen.Width;
        imagen.ScalePercent(percentage * 100);
        // Insertamos la imagen en el documento y su contenido
        doc.Add(imagen);
        doc.Add(Chunk.NEWLINE);
        doc.Add(new Paragraph("Hospital General de Alicante", _standardFont));
        doc.Add(Chunk.NEWLINE);
        doc.Add(new Paragraph("Lista de Medicos por especialidad: " + especialidad, _standardFont));
        foreach (Medico m in cuadroMedico)
        {
            if (especialidad.ToLower().Equals(m.GetEspecialidad.ToLower()))
            {
                doc.Add(Chunk.NEWLINE);
                doc.Add(Chunk.NEWLINE);
                doc.Add(new Paragraph("----------------------------------"));
                doc.Add(new Paragraph("Médico:" + m.GetNombre, _standardFont));
                doc.Add(Chunk.NEWLINE);
                doc.Add(new Paragraph("Disponibilidad:" + m.GetDisponibilidad));
                doc.Add(new Paragraph("----------------------------------"));           
            }
        }
        doc.Close();
        aviso.Close();
    }
    //Login usuarios //////////////////////////////////////////
    private static bool Registro(ArrayList user)
    {
        bool valid = false;
        if (user.Count > 0)
        {
            while (!valid)
            {
                string nom, pass;
                Console.SetCursorPosition((Console.WindowWidth / 2) - 5, Console.WindowHeight / 2);
                Console.WriteLine("Nombre usuario:");
                Console.SetCursorPosition((Console.WindowWidth / 2) - 5, Console.WindowHeight / 2 + 1);
                nom = Console.ReadLine();
                Console.Clear();
                Console.SetCursorPosition((Console.WindowWidth / 2) - 5, Console.WindowHeight / 2);
                Console.WriteLine("Clave usuario:");
                Console.SetCursorPosition((Console.WindowWidth / 2) - 5, Console.WindowHeight / 2 + 1);
                pass = Console.ReadLine();
                Console.Clear();

                if (Acceso(nom, pass, user))
                {
                    Console.Clear();
                    Console.SetCursorPosition((Console.WindowWidth / 2) - 5, Console.WindowHeight / 2);
                    Console.WriteLine("Bienvenido {0}", nom);
                    Thread.Sleep(2000);
                    Console.Clear();
                    valid = true;
                }
                else
                {
                    Console.SetCursorPosition((Console.WindowWidth / 2) - 5, Console.WindowHeight / 2);
                    Console.WriteLine("Acceso denegado ");
                    Thread.Sleep(2000);
                    Console.Clear();
                }
            }
            return true;
        }
        return false;
    }
    // acceso /////////////////////////////////////////////
    private static bool Acceso(string nom, string pass,ArrayList user)
    {
        foreach(User u in user)
        {
            if (u.ONombre.ToLower().Equals(nom.ToLower()) && u.OClave.Equals(pass))
                return true;
        }
        return false;
    }
    //cargar lista usuarios //////////////////////////////////////////
    private static ArrayList LoadUser()
    {
        Console.BackgroundColor = ConsoleColor.Gray;
        ArrayList usuarios = new ArrayList();
        try
        {
            string[] habilitados = File.ReadAllLines("usuarios.txt");
            string correcto= habilitados.Length < 1 ? "Hable con el administrador del sistema " +
                "problemas con los usuarios registrados." : "";
            Console.WriteLine(correcto);
            if (habilitados.Length > 0)
            {
                foreach (string s in habilitados)
                {
                    string[] datos = s.Split(",");
                    for (int i = 0; i < datos.Length; i++)
                    {
                        usuarios.Add(new User(datos[0], datos[1]));
                    }
                }
                return usuarios;
            }
        }
        catch(PathTooLongException)
        {
            Console.WriteLine("Nombre de archivo muy largo.");
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("Nombre de archivo no encontrado.");
        }
        catch (IOException)
        {
            Console.WriteLine("Problemas al Escribir o leer el archivo.");
        }
        catch (Exception e)
        {
            Console.WriteLine("Error inesperado: "+ e.Message);
        }
        return usuarios;
    }
    //cargar Agenda ///////////////////////////////////////////
    private static List<Cita> CargarAgenda()
    {
        List<Cita> AgendaDiaria = new List<Cita>();
        int y = 18;
        try
        {
            string[] agenda = File.ReadAllLines("agenda.txt");
            foreach (string s in agenda)
            {
                string[] datos = s.Split(";");

                string newCliente = datos[0];
                DateTime newFecha = Convert.ToDateTime(datos[1]);
                DateTime newHora = Convert.ToDateTime(datos[2]);
                string newMedico = datos[3];
                string newSintoma = datos[4];
                string newEmail = datos[5];
                short newCodigo = Convert.ToInt16(datos[6]);
                AgendaDiaria.Add(new Cita(newCliente, newFecha, newHora, newSintoma, newMedico,newEmail,newCodigo));
            }
            Console.WriteLine();
        }
        catch (PathTooLongException)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Nombre del fichero muy largo.");
        }
        catch (FileNotFoundException)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Nombre del fichero no encontrado");
        }
        catch (IOException)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Error de lectura");
        }
        catch (Exception e)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Error inesperado: {0}", e.Message);
        }
        return AgendaDiaria;
    }
    //cargar médicos ////////////////////////////////////////////////
    private static List<Medico> CargarMedicos()
    {
        int y = 18;
        List<Medico> cuadroMedico = new List<Medico>();
        try
        {
            string[] medicos = File.ReadAllLines("medicos.txt");
            foreach (string s in medicos)
            {
                string[] dtMed = s.Split(";");
                cuadroMedico.Add(new Medico(dtMed[0], dtMed[1], dtMed[2],Convert.ToInt16( dtMed[3]),
                    dtMed[4], dtMed[5]));
            }
        }
        catch (PathTooLongException)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Nombre del fichero muy largo.");
        }
        catch (FileNotFoundException)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Nombre del fichero no encontrado");
        }
        catch (IOException)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Error de lectura");
        }
        catch (Exception e)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Error inesperado: {0}", e.Message);
        }
        return cuadroMedico;
    }
    //cargar clientes ////////////////////////////////////////////////
    private static List<Cliente> CargarClientes()
    {
        int y = 18;
        List<Cliente> clientes = new List<Cliente>();
        try
        {
            string[] abonados= File.ReadAllLines("clientes.txt");
            foreach (string s in abonados)
            {
                string[] abonado = s.Split(";");
                clientes.Add(new Cliente(abonado[0], abonado[1], abonado[2], Convert.ToInt16(abonado[3]),
                    Convert.ToByte(abonado[4]), abonado[5]));
            }
        }
        catch (PathTooLongException)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Nombre del fichero muy largo.");
        }
        catch (FileNotFoundException)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Nombre del fichero no encontrado");
        }
        catch (IOException)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Error de lectura");
        }
        catch (Exception e)
        {
            Console.SetCursorPosition(5, y);
            Console.WriteLine("Error inesperado: {0}", e.Message);
        }
        return clientes;
    }
    /*enviar email :Para el correcto funcionamiento la cuenta de salida
    debe tener habilitado el acceso a aplicaciones menos seguras*/
    private static  void EnviarCorreo(string email)
    {
        MailMessage correo = new MailMessage();
        correo.From = new MailAddress("proyectoHospitalCSharp@gmail.com", "Resguardo cita", System.Text.Encoding.UTF8);//Correo de salida
        correo.To.Add(email); //Correo destino?
        correo.Subject = "Resguardo cita Médica"; //Asunto
        correo.Body = "No olvide su cita con el Médico."; //Mensaje del correo
        correo.Attachments.Add(new Attachment(GetStreamFile(AppDomain.CurrentDomain.BaseDirectory+"Aviso.pdf"), "Aviso.pdf", "application/pdf"));
        correo.IsBodyHtml = true;
        correo.Priority = MailPriority.Normal;
        SmtpClient smtp = new SmtpClient();
        smtp.UseDefaultCredentials = false;
        smtp.Host = "smtp.gmail.com"; //Host del servidor de correo
        smtp.Port = 25; //Puerto de salida
        smtp.Credentials = new System.Net.NetworkCredential("proyectoHospitalCSharp@gmail.com", "p@ssw0rD1");//Cuenta de correo
        ServicePointManager.ServerCertificateValidationCallback = delegate (object s, X509Certificate certificate, X509Chain chain, 
            SslPolicyErrors sslPolicyErrors) { return true; };
        smtp.EnableSsl = true;//True si el servidor de correo permite ssl
        smtp.Send(correo);
    }
    private static Stream GetStreamFile(string filePath)
    {
        using (FileStream fileStream = File.OpenRead(filePath))
        {
            MemoryStream memStream = new MemoryStream();
            memStream.SetLength(fileStream.Length);
            fileStream.Read(memStream.GetBuffer(), 0, (int)fileStream.Length);
            return memStream;
        }
    }
    /// guardar datos
    private static void GuardarAgenda(List<Cita> agenda)
    {
        try
        {
            StreamWriter fichAgenda = new StreamWriter("agenda.txt");
            foreach (Cita c in agenda)
            {
                string dia = c.GetDia.Day + "/" + c.GetDia.Month + "/" + c.GetDia.Year;              
                string hora = c.GetHora.Hour + ":" + c.GetHora.Minute;
                fichAgenda.WriteLine(c.GetCliente + ";" + dia + ";" + hora + ";" +
                    c.GetMedico + ";" + c.GetSintomas + ";" + c.GetEmail+";"+c.GetCodigo);
            }
            fichAgenda.Close();
        }
        catch (PathTooLongException)
        {
            Console.WriteLine("Nombre de archivo muy largo.");
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("Nombre de archivo no encontrado.");
        }
        catch (IOException)
        {
            Console.WriteLine("Problemas al Escribir o leer el archivo.");
        }
        catch (Exception e)
        {
            Console.WriteLine("Error inesperado: " + e.Message);
        }
    }

    private static void GuardarMedicos(List<Medico> cuadroMedico)
    {
        try
        {           
            StreamWriter fichMedico = new StreamWriter("medicos.txt");
            foreach (Medico m in cuadroMedico)
            {
                fichMedico.WriteLine(m.GetNombre + ";" + m.GetDireccion + ";" + m.GetTlf +
                    ";" + m.GetCodigo + ";" + m.GetEspecialidad + ";" + m.GetDisponibilidad);
            }
            fichMedico.Close();
        }
        catch (PathTooLongException)
        {
            Console.WriteLine("Nombre de archivo muy largo.");
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("Nombre de archivo no encontrado.");
        }
        catch (IOException)
        {
            Console.WriteLine("Problemas al Escribir o leer el archivo.");
        }
        catch (Exception e)
        {
            Console.WriteLine("Error inesperado: " + e.Message);
        }
    }

    private static void GuardarClientes(List<Cliente> clientes)
    {
        try
        {
            StreamWriter fichCliente = new StreamWriter("clientes.txt");
            foreach (Cliente nc in clientes)
            {
                fichCliente.WriteLine(nc.GetNombre + ";" + nc.GetDireccion + ";" + nc.GetTlf + ";" + nc.GetCodigo +
                    ";" + nc.GetEdad + ";" + nc.GetEmail);
            }
            fichCliente.Close();
        }
        catch (PathTooLongException)
        {
            Console.WriteLine("Nombre de archivo muy largo.");
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("Nombre de archivo no encontrado.");
        }
        catch (IOException)
        {
            Console.WriteLine("Problemas al Escribir o leer el archivo.");
        }
        catch (Exception e)
        {
            Console.WriteLine("Error inesperado: " + e.Message);
        }
    }
    // método para pedir datos
    private static string PedirDatos(string txt)
    {
        Console.WriteLine(txt + ":");
        return Console.ReadLine();
    }
    //interfaz Archivos
    private static void GenerarArchivo(List<Cliente> clientes, List<Medico> cuadroMedico, List<Cita> agenda)
    {
        Console.Clear();
        Console.SetCursorPosition(0, 3);
        string elegir = PedirDatos("Listado a convertir (1)CLIENTES/ (2)CUADROMÉDICO/ (3)AGENDA");
        switch (elegir)
        {
            case "1":GenArCliente(clientes); break;
            case "2": GenArMedico(cuadroMedico); break;
            case "3": GenArAgenda(agenda); break;
            default:
                Console.WriteLine("Opción no disponible.");
                Thread.Sleep(1500);
                Console.Clear();
                break;
        }
    }
    //csv o xls cliente
    private static void GenArCliente(List<Cliente> clientes)
    {
        string tipo = PedirDatos("Tipo de archivo (1)CSV/(2)Excel");
        switch (tipo)
        {
            case "1":CrearCsvCliente(clientes); break;
            case "2":CrearExcelCliente(clientes); break;
            default:Console.WriteLine("Opción no disponible.");
                Thread.Sleep(2000);
                Console.Clear();
                break;
        }
        Console.WriteLine("Archivo generado.");
        Thread.Sleep(2000);
        Console.Clear();
    }

    private static void CrearCsvCliente(List<Cliente> clientes)
    {
        clientes.Sort();
        string ubicacion =AppDomain.CurrentDomain.BaseDirectory +"cliente.csv";
        string caracter = "\n";
        StringBuilder datos1 = new StringBuilder();      
        datos1.AppendLine(string.Join(caracter, clientes));       
        File.WriteAllText(ubicacion, datos1.ToString());
    }

    private static void CrearExcelCliente(List<Cliente> clientes)
    {
        string pathFile = AppDomain.CurrentDomain.BaseDirectory + "clientes.xlsx";

        SLDocument XLS = new SLDocument();

        System.Data.DataTable dt = new System.Data.DataTable();       

        //columnas
        dt.Columns.Add("Nombre", typeof(string));
        dt.Columns.Add("Dirección", typeof(string));
        dt.Columns.Add("Teléfono", typeof(string));
        dt.Columns.Add("Código", typeof(short));
        dt.Columns.Add("Edad", typeof(byte));

        //filas
        foreach(Cliente nc in clientes)
        {
            dt.Rows.Add(nc.GetNombre,nc.GetDireccion,nc.GetTlf,nc.GetCodigo,nc.GetEdad);
        }
        XLS.ImportDataTable(1, 1, dt, true);

        XLS.SaveAs(pathFile);

    }
    // csv o xmls Medico
    private static void GenArMedico(List<Medico> cuadroMedico)
    {
        string tipo = PedirDatos("Tipo de archivo (1)CSV/(2)Excel");
        switch (tipo)
        {
            case "1": CrearCsvMedico(cuadroMedico); break;
            case "2": CrearExcelMedico(cuadroMedico); break;
            default:
                Console.WriteLine("Opción no disponible.");
                Thread.Sleep(1500);
                Console.Clear();
                break;
        }
        Console.WriteLine("Archivo generado.");
        Thread.Sleep(2000);
        Console.Clear();
    }

    private static void CrearExcelMedico(List<Medico> cuadroMedico)
    {
        string pathFile = AppDomain.CurrentDomain.BaseDirectory + "medicos.xlsx";

        SLDocument XLS = new SLDocument();

        System.Data.DataTable dt = new System.Data.DataTable();        

        //columnas
        dt.Columns.Add("Nombre", typeof(string));
        dt.Columns.Add("Dirección", typeof(string));
        dt.Columns.Add("Código", typeof(short));
        dt.Columns.Add("Especialidad", typeof(string));
        dt.Columns.Add("Disponibilidad", typeof(string));
  
        //filas
        foreach (Medico nc in cuadroMedico)
        {
            dt.Rows.Add(nc.GetNombre, nc.GetDireccion, nc.GetCodigo, nc.GetEspecialidad,nc.GetDisponibilidad);
        }
        XLS.ImportDataTable(1, 1, dt, true);

        XLS.SaveAs(pathFile);
    }

    private static void CrearCsvMedico(List<Medico> cuadroMedico)
    {
        cuadroMedico.Sort();
        string ubicacion = AppDomain.CurrentDomain.BaseDirectory + "medicos.csv";
        string caracter = "\n";
        StringBuilder datos = new StringBuilder();
        datos.AppendLine(string.Join(caracter, cuadroMedico));
        File.WriteAllText(ubicacion, datos.ToString());
    }

    //csv o xmls Citas
    private static void GenArAgenda(List<Cita> agenda)
    {
        string tipo = PedirDatos("Tipo de archivo (1)CSV/(2)Excel");
        switch (tipo)
        {
            case "1": CrearCsvCita(agenda); break;
            case "2": CrearExcelCita(agenda); break;
            default:
                Console.WriteLine("Opción no disponible.");
                Thread.Sleep(1500);
                Console.Clear();
                break;
        }
        Console.WriteLine("Archivo generado.");
        Thread.Sleep(2000);
        Console.Clear();
    }

    private static void CrearExcelCita(List<Cita> agenda)
    {
        string pathFile = AppDomain.CurrentDomain.BaseDirectory + "agenda.xlsx";

        SLDocument XLS = new SLDocument();

        System.Data.DataTable dt = new System.Data.DataTable();        

        //columnas
        dt.Columns.Add("Cliente", typeof(string));
        dt.Columns.Add("Día", typeof(string));
        dt.Columns.Add("Hora", typeof(string));
        dt.Columns.Add("Sintomas", typeof(string));        
        dt.Columns.Add("Médico", typeof(string));
        dt.Columns.Add("Email", typeof(string));
        dt.Columns.Add("Código", typeof(short));

        //filas
        foreach (Cita nc in agenda)       
        {
            string minute;
            if (nc.GetHora.Minute < 10)
                minute = "0" + nc.GetHora.Minute;
            else
                minute = Convert.ToString(nc.GetHora.Minute);
            string hora = nc.GetHora.Hour + ":" + minute;
            string dia = nc.GetDia.Day+"/"+nc.GetDia.Month+"/"+nc.GetDia.Year;
            dt.Rows.Add(nc.GetCliente, dia,hora, nc.GetSintomas, nc.GetMedico, nc.GetEmail,nc.GetCodigo);
        }
        XLS.ImportDataTable(1, 1, dt, true);

        XLS.SaveAs(pathFile);
    }

    private static void CrearCsvCita(List<Cita> agenda)
    {
        
        agenda.Sort();
        string ubicacion = AppDomain.CurrentDomain.BaseDirectory + "agenda.csv";
        string caracter = "\n";
        StringBuilder datos = new StringBuilder();
        datos.AppendLine(string.Join(caracter, agenda));
        File.WriteAllText(ubicacion, datos.ToString());
    } 

    //Menu Principal//////////////////////////////////
    private static void MenuPrincipal(DateTime a, out bool test)
    {
        string eleccion;
        Console.Clear();
        do
        {
            test = false;
            CrearMarco();
            Console.ForegroundColor = ConsoleColor.Black;
            Console.SetCursorPosition(Console.WindowWidth - 20, Console.WindowHeight - 4);
            Console.WriteLine(" ----------------");
            Console.SetCursorPosition(Console.WindowWidth - 20, Console.WindowHeight - 3);
            Console.WriteLine("| " + Menus[0] + " |");
            Console.SetCursorPosition(Console.WindowWidth - 20, Console.WindowHeight - 2);
            Console.WriteLine(" ----------------");
            Console.SetCursorPosition(Console.WindowWidth / 2, 1);
            Console.WriteLine(" -----------------------");
            Console.SetCursorPosition(Console.WindowWidth / 2, 2);
            Console.WriteLine("| Bienvenido: {0}/{1}/{2} |", a.Day, a.Month, a.Year);
            Console.SetCursorPosition(Console.WindowWidth / 2, 3);
            Console.WriteLine(" -----------------------");
            Console.SetCursorPosition(2, 4);
            Console.WriteLine(" ---------- ");
            Console.SetCursorPosition(2, 5);
            Console.WriteLine("| 1.Citas. |");
            Console.SetCursorPosition(2, 6);
            Console.WriteLine(" ---------- ");
            Console.SetCursorPosition(2, 7);
            Console.WriteLine(" ------------- ");
            Console.SetCursorPosition(2, 8);
            Console.WriteLine("| 2.Clientes. |");
            Console.SetCursorPosition(2, 9);
            Console.WriteLine(" ------------- ");
            Console.SetCursorPosition(2, 10);
            Console.WriteLine(" ------------");
            Console.SetCursorPosition(2, 11);
            Console.WriteLine("| 3.Médicos. |");
            Console.SetCursorPosition(2, 12);
            Console.WriteLine(" ------------ ");
            Console.SetCursorPosition(2, 13);
            Console.WriteLine(" ---------------------- ");
            Console.SetCursorPosition(2, 14);
            Console.WriteLine("| 4.Generar excel,csv. |");
            Console.SetCursorPosition(2, 15);
            Console.WriteLine(" ---------------------- ");
            Console.SetCursorPosition(2, 16);
            Console.WriteLine(" ---------- ");
            Console.SetCursorPosition(2, 17);
            Console.WriteLine("| S.Salir. |");
            Console.SetCursorPosition(2, 18);
            Console.WriteLine("  ---------- ");
            Console.SetCursorPosition(2, 19);
            eleccion = Console.ReadLine();
            switch (eleccion)
            {               
                case "1": CrearCitas(a, ref clientes, ref cuadroMedico,ref  agenda); break;
                case "2": CrearClientes(a, ref clientes); break;
                case "3": CrearMédicos(a, ref cuadroMedico); break;
                case "4": GenerarArchivo(clientes,cuadroMedico,agenda); break;
                case "s":
                case "S": test = true; break;
                default:
                    Console.SetCursorPosition(2, 20);
                    Console.WriteLine("Opción no disponible"); Thread.Sleep(1000);
                    Console.Clear(); break;
            }
        } while (!test);
        GuardarAgenda(agenda);
        GuardarClientes(clientes);
        GuardarMedicos(cuadroMedico);
    }

    private static void CrearMarco()
    { 
        int x = 0,y=1;
        Console.ForegroundColor = ConsoleColor.DarkMagenta;
        for(int i = 0; i < Console.WindowWidth-2; i++)
        {
            Console.SetCursorPosition(x+1, 0);
            Console.Write("-");
            Console.SetCursorPosition(x+1, Console.WindowHeight-1);
            Console.Write("-");
            x++;          
        }
        for(int j = 0; j < Console.WindowHeight-2; j++)
        {
            Console.SetCursorPosition(0, y);
            Console.Write("|");
            Console.SetCursorPosition(Console.WindowWidth-1, y);
            Console.Write("|");
            y++;
        }
    }
}

